package com.data.toan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToanApplication.class, args);
	}

}
