package com.data.toan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToanApplicationTests {

	@Test
	void contextLoads() {
	}

}
